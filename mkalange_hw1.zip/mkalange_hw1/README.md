README
Mike Kalange

The enclosed functions are python and c programs which take a number of objects and iterations as arguments, create arrays with that many objects and update their coordinates "iterations" times.


Part 1
------

a. I did powers of 2 from 2^8 to 2^24 (as indicated in the assignment outline) normalized to the value of 2^24 (16,777,216) * 2^2 . So for 2^8 objects we have 2^18 iterations. For 2^9 I did 2^17 iterations etc. This seemed to be a reasonable way of 

b. For all sizes of objects I did average of 5 trials at the iteration counts done in part 1.
I really have no idea what makes a reasonable benchmark and for larger object counts it ended up taking long enough that I have to prioritize getting it done in a "good enough" sort of way. But there are some puzzling things in my data that makes me think neither of these methods are good enough. Around the higher end of the object range the average times bounce around rather wildly... (2^16 is an outright anomaly).

c. In .zip

Part 2
------

The c program is almost line for line identical to the python program but it dynamically allocates memory for the arrays and cleans up at the end.

Graphs and data as PDF in .zip 
Identical parameters run for timing purposes although I observed that much larger object sizes and iterations are feasible.

For reference here are the times for 100 million objects at 10 iterations using floats and the c program:
0.00644654
0.00644278
0.00649785
0.00642724
0.00639895
Which are really stable and really low (it actually gets faster the more things in the array).

Part 3
------
Graphs and data in PDF w/ Part 2
The int types speed scales pretty directly with their precision, double is the slowest with floats somewhere in the middle. I don't really have a great grasp on why the floats stack up where they do but i suppose it is of note that anecdotally, floats also showed the greatest variability in runtime.


Part 4
------

using /usr/bin/time --verbose as indicated in the assignment we can get some interesting measurements.
I've isolated the relevant ones below.

Using 1000000 objects and 100 iterations

For Python:
Max rss (resident set size) in kbytes: 236568
Wall Clock elapsed time: 0:46.51

For C (using floats):
Max rss in kbytes: 24296
Wall Clock elapsed time: 0:00.76

The point here is pretty stark; the c program is orders of magnitude faster and more space efficient. Whatever the hell is going on in python is wildly inferior on the system level.


