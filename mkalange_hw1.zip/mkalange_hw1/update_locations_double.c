/*
    This program generates N random coordinates in space (3D), and N random
    velocity vectors. It then iterates M times to update the locations based
    on the velocity.
    Finally, it outputs the sum of all coordinates as a checksum of the computation.
    Coordinates start in the range [-1000:1000] per dimension.
    Velocities are chosen from the range [-1:1] per dimension.
*/

#include <stdlib.h>
#include <stdio.h> 
#include <time.h>

// ###############
// Create a list of 'size' floating point numbers in the range [-bound, bound]
double * generate_random_list(int size, float bound)
{
    // these lines are for clarity so the calculation of rand_list[i]
    // doesn't end up looking like bound -(-bound) etc etc
    float lo = -bound;
    float hi = bound;
    double *rand_list;

    rand_list = (double*) malloc(sizeof(double) * size);
    
    if (rand_list == NULL)
        {
            fprintf(stderr, "out of memory\n");
            exit(EXIT_FAILURE);
        }
    
    for (int i = 0; i < size; i++)
        {
            rand_list[i] = (double)((((float)rand()+1)/((float)RAND_MAX+2))*(hi-lo) + lo);
        }
    
    return rand_list;
}

// ###############
// Update location by velocity, one time-step
void update_coords(double x[], double y[], double z[], double vx[], double vy[], double vz[], int size)
{
    for (int i = 0; i < size; i++)
    {
        x[i] = x[i] + vx[i];
        y[i] = y[i] + vy[i];
        z[i] = z[i] + vz[i];
    }
}

// ###############
// Sums elements of input array to do the checksum in main
double sum(double array[],int size)
{
    double sum = 0.0;
    for (int i = 0; i < size; i++)
    {
        sum = sum + array[i];
    }
    return sum;
}

// Main:

int main(int argc, char** argv) 
{
    
    if (argc != 3)
    {
        printf("Required arguments: vector_length(N) and iterations_num(M)");
        return -1;
    }
    
    int size = atoi(argv[1]); 
    int iters = atoi(argv[2]);
    float bound1 = 1000.0;
    float bound2 = 1.0;

    srand((unsigned)size);
    
    double * x = generate_random_list(size,bound1);
    double * y = generate_random_list(size,bound1);
    double * z = generate_random_list(size,bound1);
    double * vx = generate_random_list(size,bound2);
    double * vy = generate_random_list(size,bound2);
    double * vz = generate_random_list(size,bound2);

    clock_t t;
    double time_taken;
    for (int i = 0; i < iters; i++)
    {
        t = clock();
        update_coords(x,y,z,vx,vy,vz,size);
        t = clock() - t; 
        time_taken = time_taken + ((double)t)/CLOCKS_PER_SEC;
    }

    double chksum = sum(x,size) + sum(y,size) + sum(z,size);
    printf("Mean time per coordinate: %9.8f%s \n", (1000000 * time_taken / ((float)size * (float)iters)), "us");
    printf("Final checksum is: %f \n" , chksum);
    
    free(x);
    free(y);
    free(z);
    free(vx);
    free(vy);
    free(vz);

    return 0;
}